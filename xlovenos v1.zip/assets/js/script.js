        const members = document.querySelectorAll('.member');
        let currentIndex = 0;
        
        function rotateMembers() {
            // Hide all members
            members.forEach(member => member.classList.remove('active'));
            
            // Show next member
            currentIndex = (currentIndex + 1) % members.length;
            members[currentIndex].classList.add('active');
        }
        
        // Rotate every 5 seconds
        setInterval(rotateMembers, 5000);
        
        // Initial rotation setup
        setTimeout(rotateMembers, 5000);
        
                // Login Form Functionality
        const listBtn = document.querySelector('.list-btn');
        const menuOverlay = document.querySelector('.menu-overlay');
        const closeBtn = document.querySelector('.close-btn');
        
        listBtn.addEventListener('click', () => {
            menuOverlay.classList.add('active');
        });
        
        closeBtn.addEventListener('click', () => {
            menuOverlay.classList.remove('active');
        });
        